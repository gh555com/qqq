




























































 那是我的梦境。

 ещё whisper for my daughter的梦0.

<p align="center">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/loq.gif" width="100%" alt="的梦gaea">
  © 2005 gh555.com All Rights Reserved.
</p>

 Full source code transparency, security, and auditability are guaranteed. [Feedback & Issues](https://github.com/gh555com/qqq/issues)

 Original name: qqq    ![Open VSX](https://img.shields.io/open-vsx/dt/gh555/qqq?label=installs&color=blue)

 Open VSX: https://open-vsx.org/extension/gh555/qqq


 You need not have opened a note-taking application specially.

 **√**  VS Code (Cursor, Antigravity, etc.) can also serve as an all-media paste-friendly notebook. How? Enable qqq.



## ✦q✦ Enhanced Ctrl+V: Without changing any original features, Paste everything  anywhere in any document
<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q1_4.gif" width="100%" alt="Paste Screenshot">
</p>

 Works with any document e.g. ".txt", ".1", any file extension, or no extension.

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q23.gif" width="100%" alt="Paste image files directly">
</p>

Let me be honest, via  qqq you can paste txt, exe, psd, mp3, folder, mp4.... if you want. Why not?

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q3_3.gif" width="100%" alt="Paste any file">
</p>

 qqq in, ctrl + v. If you don't like key combinations, try F2.

 You can organize your ideas now.

 There’s just one more small thing - you need to be able to jump between arbitrary directories:



## ✦q✦ A Revolution of the Tab Key (without breaking the default Tab behavior)

 Trigger: Press Tab while the window has focus but is not in editing mode, or directly click the Roam command/button.

Before 2026, Tab helped you code fast.

Now, I advocate for tab (=**Roam**) to help you expand rapidly: reaching any location at the speed of thought.

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q4_1.gif" width="100%" alt="Roam file explorer">
</p>

**Roam**, from qqq, is a file explorer:

1. **Nice**: It can reach any location, no longer limited to project folders. You can even map remote disks locally, skip ssh.

2. **Fast**: There’s no need to rage because you’re waiting for just a list — not even on my servers and VMs with maxed-out system resources.

3. **Rock-solid**: Based on transactional file operations, it compensates for VS Code's inherent shortcomings in large-scale file deletion and copying. For details on VS Code's official file manager flaws, see: [VS_Code_Official_File_Explorer_Limitations.md](https://github.com/gh555com/qqq/blob/qq/docs/VS_Code_Official_File_Explorer_Limitations.md)

4. **User-friendly**: Displays recent visits for quick jumps; `a`, `x` keys open the administrator terminal; supports quick filtering; remembers fine-grained list and sorting preferences; fully operable via keyboard: tab opens Roam → focus enters the filename edit box → filename → enter → focus enters the newly created file (already in edit stance) 🡺 I want you to expand faster; a large close button - if you don't like Roam, that's what I prepared for you, but more likely, you'll get a resource manager that will eventually merge with your consciousness.

So, find the faster version of yourself.



A little hint:

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q6.gif" width="100%" alt="How to select a folder？">
</p>

 With this trick, you can multi-select folders (or a mix of files and folders) to copy, delete, get size in bulk.

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q7.gif" width="100%" alt="Most visited always closest to you">
</p>

 try the shortcut key of Roam:

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/key.gif" width="80%" alt="shortcut key">
</p>

Press `Space` on selected item: ignore any preferences, request its size.

Press `1` to scroll to list top.
Press `2` to scroll to list bottom.


  qqq Roam serves as your default start page for blank windows. Make the most of the **`Q`** key to open projects or documents;  make the most of the **`W`** key to open your music, videos, and games.

 As of v16.1, we’re thrilled to introduce the `Space + Q` keyboard shortcut to invoke Roam. Enjoy!



## ✦q✦ Hot features

 #### Paste HTML

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q5_3.gif" width="100%" alt="Paste HTML">
</p>

 Test URL: https://mbd.baidu.com/newspage/data/landingsuper?context=%7B%22nid%22%3A%22news_9166282253401607575%22%7D&n_type=1

This URL contains a mix of 3 videos and multiple images. Select all on the web page, Copy → Paste. Test objectives: 1. All 3 videos have been downloaded. 2. The positions (order) of text, images, and videos are correct. 3. No garbled characters should appear. 4. After repeated operations, the same resources should only be saved once on the hard drive (identical images and videos will be deduplicated by fingerprinting).








 #### Export Doc

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q8.gif" width="100%" alt="export doc">
</p>

 .doc: Compatible with Word 2003.
 .docx: Smaller size.




 #### Export Zip: The best way for portable and presentation resources.

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q9.gif" width="100%" alt="export Zip">
</p>


 #### Paste stream videos

<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/q_video.gif" width="100%" alt="Network stream video ">
</p>



 ####  Clean up orphaned files

 #### Clipboard history cards





  ## How to install ##

For the best practice, download qqq from the official Marketplace at https://marketplace.visualstudio.com/items?itemName=gh555com.q3. or, actually, the best way is to simply open any of your IDEs, type "q3" directly into the official extension marketplace in the sidebar, and install it:
<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/install.png" alt="How to install">
</p>

and then you can switch languages: zh、zh-tw、en、ja、de、ko、ru、ar、es、fr、pt-BR:
<p align="left">
  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/i18.png" alt="i18n">
</p>


 All  operating system (Windows, Linux, macOS) and processor architecture (x64, ARM, ARM64, Apple Silicon) in: https://github.com/gh555com/qqq/releases or https://open-vsx.org/extension/gh555/qqq


 ## About qqq Resource Footprint
Built on a highly efficient Rust-based underlying architecture with extreme performance optimization, qqq's idle CPU and disk IO overhead approach absolute zero. Its ultra-low memory footprint is also remarkably prominent, especially in scenarios where multiple IDEs (Cursor, Antigravity, etc.) are running simultaneously with a large number of open windows. For architectural details: https://github.com/gh555com/qqq/blob/qq/docs/IO_ENGINE_v16.md


 ## Security
The source code is fully open source and available for self-compilation: https://github.com/gh555com/qqq, Windows 7 is supported, for key compilation notes: https://github.com/gh555com/qqq/blob/qq/docs/Rust%20win7.md.

The company undertakes never to collect clipboard content or any sensitive user information, and welcomes public supervision:
<p align="left">
  <img src="https://cdn.gh555.com/u/01KK1SAAR5B53SJXGNVQWP5EB6/MSNRJ5YUR7YY6.jpg" width="100%" alt="company">
</p>

<p align="left">
  <img src="https://cdn.gh555.com/u/01KK1SAAR5B53SJXGNVQWP5EB6/ZAVTVRFVTJ6ME.png " width="60%" alt="company">
</p>


Virus detection or submission: https://www.avira.com/en/analysis/submit

 Detection result based on v16.1.0:


  <img src="https://cdn.jsdelivr.net/gh/kkn1n/res@qq/qqq/Avira.jpg" alt="Avira">



  the whisper is: I miss you 的梦0.































